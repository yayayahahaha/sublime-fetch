require 'compass/import-once/activate'

http_path = "/"
css_dir = '/'
sass_dir = '/'
iamges_dir = 'images'
javascript_dir = '/'
line_comments = false