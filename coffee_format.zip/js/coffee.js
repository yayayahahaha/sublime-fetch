(function() {
  console.log('hi');

}).call(this);

