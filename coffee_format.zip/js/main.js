window.onload=function (argument) {
	try{
		$();
		console.log("The JQuery and javascript are running!");
	}catch(str){
		console.error("The JQuery is NOT running! but javascript is running!!");
	}

}