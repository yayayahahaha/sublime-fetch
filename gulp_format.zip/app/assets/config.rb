require 'compass/import-once/activate'

http_path = "/"
css_dir = 'css'
sass_dir = 'sass'
iamges_dir = 'images'
javascript_dir = 'js'