window.onload = function() {
	console.log("I'm index.js");
}